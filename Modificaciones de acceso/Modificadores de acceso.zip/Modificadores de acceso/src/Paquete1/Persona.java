package Paquete1;

public class Persona {
    public String Nombre;
    public int Edad;

    public Persona(String Nombre, int Edad) {
        this.Nombre = Nombre;
        this.Edad = Edad;
    }

    public int getEdad() {
        return Edad;
    }

    public String getNombre() {
        return Nombre;


    
}
}
