package Paquete1;

public class Main {
    public static void main(String[] args) {
Persona p = new Persona();

    }
}
