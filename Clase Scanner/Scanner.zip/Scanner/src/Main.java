import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.print("Ingresa tu edad gordito :");
        Scanner entrada= new Scanner(System.in);
int Edad= entrada.nextInt();

        System.out.println("Tu edad es ñai; "+Edad);







    }

}
