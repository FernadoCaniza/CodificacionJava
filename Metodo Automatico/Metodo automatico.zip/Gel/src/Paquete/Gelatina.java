package Paquete;

public class Gelatina {

    //Atributos
    String color;
    String sabor;

    //Metodo Constructor
    public Gelatina (String color, String sabor) {
        this.color = color;
        this.sabor = sabor;

    }
        public String getColor () {
            return color;
        }

        public void setColor (String color){
            this.color = color;
        }

        public String getSabor () {
            return sabor;
        }

        public void setSabor (String sabor){
            this.sabor = sabor;
        }



    public void mostrarInfo() {
        System.out.println("Gelatina{" +
                "color='" + color + '\'' +
                ", sabor='" + sabor + '\'' +
                '}');

    }
}