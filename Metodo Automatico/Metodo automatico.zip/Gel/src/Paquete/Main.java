package Paquete;

public class Main {
    //Crear un objeto a partir de una clase instancia
    public static void main(String[] args) {

        Gelatina g1 = new Gelatina("Veer","Limon");
        g1.mostrarInfo();
        Gelatina g2 = new Gelatina("Amarillo","banana");
        g2.mostrarInfo();
    }

}