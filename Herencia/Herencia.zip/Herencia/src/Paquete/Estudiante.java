package Paquete;

public class Estudiante extends Persona {
private int Codigo;
private int Semestre;

//Metodo Builder
    public Estudiante(String Nombre, String Apellido, int Edad, int codigo, int semestre) {
        super(Nombre, Apellido, Edad);
        Codigo = codigo;
        Semestre = semestre;
    }

    public int getCodigo() {
        return Codigo;
    }

    public int getSemestre() {
        return Semestre;
    }
public void MostrarInfo(){
        String Info = "Nombre: " + getNombre()+ "\n"+
                "Apellido: "+getApellido()+"\n"+
                "Edad: "+getEdad()+"\n"+
                "Codigo: "+getCodigo()+"\n"+
                "Semestre: "+getSemestre()+"\n";

    System.out.println(Info);
    }





}
