package Paquete;

public class Main {
    public static void main(String[] args) {
Estudiante p = new Estudiante("Raul","Albarado",50,2040,1);

p.MostrarInfo();
    }
}
