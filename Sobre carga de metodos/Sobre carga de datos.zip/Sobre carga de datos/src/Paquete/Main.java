package Paquete;

public class Main {
    public static void main(String[] args) {
double X = 3;
        double Y = 4;
        double res= operacion (X, Y );
        System.out.println("El resultado de la operacion es :  " +res);

        int x = 5;
        int y = 4;
        double res2= operacion (x, y );
        System.out.println("El resultado de la operacion es :  " +res2);

    }

private static int operacion(int x, int y){
        return x * y ;
}
private static double operacion(double x, double y){
    return x * y;
    }





















}