package Paquete;

public class Main {
    public static void main(String[] args) {
Persona p = new Persona();
   p.setEdad(16);

        System.out.println("La edad ingresada "+ p.getEdad());
    }
}
