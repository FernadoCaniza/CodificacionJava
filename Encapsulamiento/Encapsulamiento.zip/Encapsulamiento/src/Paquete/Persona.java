package Paquete;

import java.sql.SQLOutput;

public class Persona {
    private int Edad;

    public int getEdad() {
        if (this.Edad == 0) {
            System.out.println("La edad es incorrecta");
        }
        return Edad;

    }

    public void setEdad(int Edad) {
        if (Edad >= 0) {
            this.Edad = Edad;
        }
    }
}