
package logica;

import gui.Login;

public class inicio {
     public static void main(String args[]) {
    Login pan = new Login();
    pan.setVisible(true);
    pan.setLocationRelativeTo(null);
    
}
}