package logica;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
@SuppressWarnings("serial")
public class Producto implements Serializable  { 
 public Producto(){}
 @Id
 @GeneratedValue(strategy=GenerationType.AUTO)
  private int id;
 @Basic
  private String Nombre;
  private String Descripcion;
  private int Cantidad;
  private double Costo;
private double PrecioUni;

    public Producto(int id, String Nombre, String Descripcion, int Cantidad, double Costo, double PrecioUni) {
        this.id = id;
        this.Nombre = Nombre;
        this.Descripcion = Descripcion;
        this.Cantidad = Cantidad;
        this.Costo = Costo;
        this.PrecioUni = PrecioUni;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }

    public double getCosto() {
        return Costo;
    }

    public void setCosto(double Costo) {
        this.Costo = Costo;
    }

    public double getPrecioUni() {
        return PrecioUni;
    }

    public void setPrecioUni(double PrecioUni) {
        this.PrecioUni = PrecioUni;
    }
    
  

    
}
