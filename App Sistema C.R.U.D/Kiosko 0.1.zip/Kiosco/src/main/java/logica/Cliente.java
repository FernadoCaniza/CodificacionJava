
package logica;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
    public class Cliente implements Serializable  { 
       public Cliente(){} 
        @Id
 @GeneratedValue(strategy=GenerationType.AUTO)
 private int id; 
 @Basic
private String ApellidoNombre;
 private String  DNI;
 private String Celular;
private String Direccion;

    public Cliente(int id, String ApellidoNombre, String DNI, String Celular, String Direccion) {
        this.id = id;
        this.ApellidoNombre = ApellidoNombre;
        this.DNI = DNI;
        this.Celular = Celular;
        this.Direccion = Direccion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getApellidoNombre() {
        return ApellidoNombre;
    }

    public void setApellidoNombre(String ApellidoNombre) {
        this.ApellidoNombre = ApellidoNombre;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getCelular() {
        return Celular;
    }

    public void setCelular(String Celular) {
        this.Celular = Celular;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

  

    

  
}
  
 
    

