
package logica;

import java.util.List;
import persistencia.ControllerPers;




public class Controladora {
ControllerPers controls = new ControllerPers();
public void registrar (String Nombre, String Descripcion, int Cantidad, double Costo, double PrecioUni){
 Producto inve = new Producto();
  inve.setNombre(Nombre);
  inve.setDescripcion(Descripcion);
  inve.setCantidad(Cantidad);  
  inve.setCosto(Costo);
  inve.setPrecioUni(PrecioUni);
controls.registrar(inve);

}
  public  List<Producto> traerProducto() {
return controls.traerProducto();
    }

    public  void BorrarProducto(int idPro) {
  controls.BorrarProducto(idPro);
    }

    public Producto traerProducto(int idPro) {
      return controls.traerProducto(idPro);
    }
public  void modic(Producto inve, String Nombre, String Descripcion, int Cantidad, double Costo) {
   
      inve.setNombre(Nombre);
     inve.setDescripcion(Descripcion);
     inve.setCantidad(Cantidad);
     inve.setCosto(Costo);
     controls.modic(inve);
    }

    
  
}
  