
package logica;

import java.util.List;
import persistencia.ControllerPers1;


public class ControladoraCliente {
ControllerPers1 controls1 = new ControllerPers1();
public void registrar (String ApellidoNombre, String DNI,String Celular, String Direccion){
 Cliente inve1 = new Cliente();
  inve1.setApellidoNombre(ApellidoNombre);
  inve1.setDNI(DNI);
  inve1.setCelular(Celular);  
  inve1.setDireccion(Direccion);
controls1.registrar(inve1);

}
  public  List<Cliente> traerCliente() {
return controls1.traerCliente();
    }

    public  void BorrarCliente(int idCli) {
  controls1.BorrarCliente(idCli);
    }

    public Cliente traerCliente(int idCli) {
      return controls1.traerCliente(idCli);
    }
public void modic(Cliente inve1, String ApellidoNombre, String DNI, String Celular, String Direccion) {
   
     inve1.setApellidoNombre(ApellidoNombre);
     inve1.setDNI(DNI);
     inve1.setCelular(Celular);
     inve1.setDireccion(Direccion);
     controls1.modic(inve1);
    }

    
  
}
  