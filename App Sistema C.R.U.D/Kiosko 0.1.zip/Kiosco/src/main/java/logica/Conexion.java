
package logica;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
    
  Connection  cn; 
  
public Connection  conectar(){
 try {
 Class.forName("com.mysql.jdbc.Driver");
 cn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/maxiquiosco?serverTimeZone=UTC [root on Default schema]",
         "root","" );
 }catch(Exception e)
 {
 
 } 
  return cn;
  }
}
