package gui.client;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import logica.Cliente;
import logica.Conexion;
import logica.ControladoraCliente;

public class Factura extends javax.swing.JFrame {
   Cliente pro1 = new Cliente();
  ControladoraCliente control1 = null;
  Cliente inve1 = new Cliente();
Conexion con = new Conexion();
Connection cn = con.conectar();

    public Factura() {
     control1 = new ControladoraCliente();
       initComponents();
     ComboBox();
     
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtCliente = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        bntGenerar = new javax.swing.JButton();
        bntNuevo = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtDirec = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        txtPrecio = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        labeldni = new javax.swing.JLabel();
        txtDni1 = new javax.swing.JLabel();
        Txtdni = new javax.swing.JTextField();
        txtCel = new javax.swing.JTextField();
        bntGuardar = new javax.swing.JButton();
        jSpinner1 = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 251, 62));
        jPanel1.setBorder(javax.swing.BorderFactory.createMatteBorder(6, 6, 6, 6, new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Book Antiqua", 1, 36)); // NOI18N
        jLabel1.setText("Venta");

        jLabel2.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        jLabel2.setText("CLIENTE");

        txtCliente.setBorder(javax.swing.BorderFactory.createMatteBorder(4, 4, 4, 4, new java.awt.Color(0, 0, 0)));
        txtCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtClienteActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        jLabel3.setText("PRODUCTO");

        jLabel4.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        jLabel4.setText("PRECIO");

        jLabel5.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        jLabel5.setText("CANTIDAD");

        jLabel6.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        jLabel6.setText("Generar Boleta");

        bntGenerar.setText("Generar");
        bntGenerar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntGenerarActionPerformed(evt);
            }
        });

        bntNuevo.setText("Nuevo");
        bntNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntNuevoActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        jLabel7.setText("DIRECCION");

        txtDirec.setBorder(javax.swing.BorderFactory.createMatteBorder(4, 4, 4, 4, new java.awt.Color(0, 0, 0)));
        txtDirec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDirecActionPerformed(evt);
            }
        });

        jComboBox1.setFont(new java.awt.Font("Book Antiqua", 1, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        txtPrecio.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txtPrecio.setBorder(new javax.swing.border.MatteBorder(null));

        labeldni.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        labeldni.setText("DNI");

        txtDni1.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        txtDni1.setText("CELULAR");

        Txtdni.setBorder(javax.swing.BorderFactory.createMatteBorder(4, 4, 4, 4, new java.awt.Color(0, 0, 0)));

        txtCel.setBorder(javax.swing.BorderFactory.createMatteBorder(4, 4, 4, 4, new java.awt.Color(0, 0, 0)));
        txtCel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCelActionPerformed(evt);
            }
        });

        bntGuardar.setText("Guardar");
        bntGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntGuardarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(326, 326, 326)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(labeldni))
                                    .addComponent(txtDni1)
                                    .addComponent(jLabel2))
                                .addGap(72, 72, 72)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtCel)
                                    .addComponent(txtCliente, javax.swing.GroupLayout.DEFAULT_SIZE, 146, Short.MAX_VALUE)
                                    .addComponent(Txtdni))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(127, 127, 127)
                                        .addComponent(jLabel8))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(114, 114, 114)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel5)
                                                .addGap(18, 18, 18)
                                                .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel4)
                                                    .addComponent(jLabel3))
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(18, 18, 18)
                                                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(11, 11, 11))))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(bntNuevo)
                                                .addGap(26, 26, 26)
                                                .addComponent(bntGuardar))))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(50, 50, 50)
                                .addComponent(txtDirec, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(jLabel6))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(96, 96, 96)
                        .addComponent(bntGenerar)))
                .addContainerGap(72, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(48, 48, 48)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(Txtdni, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labeldni)))
                            .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtCel, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDni1)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(34, 34, 34)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtDirec, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(17, 17, 17)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(bntGenerar))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bntNuevo)
                            .addComponent(bntGuardar))))
                .addContainerGap(123, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtClienteActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed

    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void bntGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntGuardarActionPerformed
 String ApellidoNombre = txtCliente.getText();
      String DNI = Txtdni.getText();
      String Celular = txtCel.getSelectedText();
  String Direccion  = txtDirec.getText();
  control1.registrar(ApellidoNombre, DNI, Celular,Direccion);    
  MostrarMensaje("Registro Exitoso","Info","Registro");
    }//GEN-LAST:event_bntGuardarActionPerformed

    private void txtDirecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDirecActionPerformed

    }//GEN-LAST:event_txtDirecActionPerformed

    private void bntGenerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntGenerarActionPerformed
fac();
  MostrarMensaje("FACTURA CREADA","Info","PDF");
    }//GEN-LAST:event_bntGenerarActionPerformed

    private void bntNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntNuevoActionPerformed
        txtCliente.setText("");
        Txtdni.setText("");
        txtCel.setText("");
        txtDirec.setText("");  
          txtPrecio.setText("");
          jSpinner1.setValue(0);
          jComboBox1.setSelectedIndex(0);
    }//GEN-LAST:event_bntNuevoActionPerformed

    private void txtCelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCelActionPerformed
         public void MostrarMensaje(String Mensaje, String Tipo, String Titulo){
  JOptionPane optionPane = new JOptionPane(Mensaje);
  if(Tipo.equals("info")){
      optionPane.setMessageType(JOptionPane.INFORMATION_MESSAGE);
  }
  else if (Tipo.equals("Error")){
      optionPane.setMessageType(JOptionPane.ERROR_MESSAGE);
  }
  JDialog dialog = optionPane.createDialog(Titulo);
  dialog.setAlwaysOnTop(true);
  dialog.setVisible(true); 
  
         }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Txtdni;
    private javax.swing.JButton bntGenerar;
    private javax.swing.JButton bntGuardar;
    private javax.swing.JButton bntNuevo;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JLabel labeldni;
    private javax.swing.JTextField txtCel;
    private javax.swing.JTextField txtCliente;
    private javax.swing.JTextField txtDirec;
    private javax.swing.JLabel txtDni1;
    private javax.swing.JLabel txtPrecio;
    // End of variables declaration//GEN-END:variables
private PreparedStatement  selectStatement;
private PreparedStatement  updateStatement;
private PreparedStatement priceStatement;
private void ComboBox() {
// Establecer la conexión a la base de datos
try {
priceStatement = cn.prepareStatement("SELECT PRECIOUNI FROM PRODUCTO WHERE NOMBRE= ?");
} catch (SQLException e) {
e.printStackTrace();
}
// Configurar la interfaz de usuario
jComboBox1.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
String selectedProduct = (String) jComboBox1.getSelectedItem();
// Obtener el precio del producto seleccionado
try {
priceStatement.setString(1, selectedProduct);
ResultSet resultSet = priceStatement.executeQuery();
if (resultSet.next()) {
double price = resultSet.getDouble("PRECIOUNI");
txtPrecio.setText(" " + price);
}
} catch (SQLException ex) {
ex.printStackTrace();
}
}
});
    bntGenerar.addActionListener(new ActionListener() {
            @Override
           public void actionPerformed(ActionEvent e) {
               actualizarCantidad();
           }
           });
        try {
         
            selectStatement = cn.prepareStatement("SELECT PRECIOUNI FROM PRODUCTO WHERE NOMBRE = ?");
            
            updateStatement = cn.prepareStatement("UPDATE PRODUCTO SET CANTIDAD = CANTIDAD - ? WHERE NOMBRE = ?");
            
//             Obtener los productos de la base de datos y agregarlos al combo box
            Statement statement = cn.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT NOMBRE FROM PRODUCTO");
            while (resultSet.next()) {
                jComboBox1.addItem(resultSet.getString("NOMBRE"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
 }

}

private void actualizarCantidad() {
    String producto = (String) jComboBox1.getSelectedItem();
    int cantidad = (int) jSpinner1.getValue();
    try {
//             Obtener el precio del producto seleccionado
            selectStatement.setString(1, producto);
            ResultSet resultSet = selectStatement.executeQuery();
            if (resultSet.next()) {               
//                 Actualizar la cantidad en la base de datos
                updateStatement.setInt(1, cantidad);
                updateStatement.setString(2, producto);
                double price = resultSet.getDouble("PRECIOUNI");
                txtPrecio.setText(" " + price*cantidad);
                updateStatement.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

}

private void fac  () {
// Datos de la factura
 String alphabet = "123456789";
 Random r = new Random();
 Random r2 = new Random();
char Carac = alphabet.charAt(r.nextInt(alphabet.length()));
char Carac2 = alphabet.charAt(r.nextInt(alphabet.length()));
String NumeroFactura = "FAC-"+"0"+Carac+"0"+Carac2+"0";
String Fecha = ""+ LocalDate.now()+"  "+LocalTime.now();
String ApellidoNombre = txtCliente.getText();
String DNI = String.valueOf(Txtdni.getText());
String direccionCliente = "Calle Principal 123";
int value = (int) jSpinner1.getValue();
String producto = (String) jComboBox1.getSelectedItem();
String Precio = (txtPrecio.getText());
double subtotal = 100.0;
double impuesto = subtotal * 0.18;
double total = subtotal + impuesto;


// Crear el documento
try{
// Abrirel documento
Document document = new Document(PageSize.LETTER);
String archivoPDF = "C:/Users/Weon/Desktop/deuda_fmt csv/factura.pdf";
PdfWriter.getInstance(document,new FileOutputStream(archivoPDF));


document.open();
//Imagen
Image imagen = Image.getInstance("C:/Users/Weon//Desktop/Don Gordito.png");
imagen.setAbsolutePosition(50f, 680f);
imagen.scaleAbsoluteHeight(100f);
imagen.scaleAbsoluteWidth(100f);
// Configurar fuentes
Font fontTitulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
Font fontNormal = FontFactory.getFont(FontFactory.HELVETICA, 12);
// Agregar título
Paragraph titulo = new Paragraph("Maxiquiosco DonGordito", fontTitulo);
titulo.setAlignment(Element.ALIGN_CENTER);
titulo.setSpacingAfter(20);
document.add(titulo);
// Agregar información de la factura
Paragraph infoFactura = new Paragraph();
infoFactura.add(new Chunk("Número de factura: ", fontNormal));
infoFactura.add(new Chunk(NumeroFactura, fontNormal));
infoFactura.add(Chunk.NEWLINE);
infoFactura.add(new Chunk("Fecha: ", fontNormal));
infoFactura.add(new Chunk(Fecha, fontNormal));
infoFactura.setAlignment(Element.ALIGN_RIGHT);
infoFactura.setSpacingAfter(10);
document.add(infoFactura);
// Agregar información del cliente
Paragraph infoCliente = new Paragraph();
infoCliente.add(new Chunk("Cliente: ", fontNormal));
infoCliente.add(new Chunk(ApellidoNombre, fontNormal));
infoCliente.add(Chunk.NEWLINE);
infoCliente.add(new Chunk("DNI :", fontNormal));
infoCliente.add(new Chunk(DNI, fontNormal));
infoCliente.add(Chunk.NEWLINE);
infoCliente.add(new Chunk("Dirección: ", fontNormal));
infoCliente.add(new Chunk(direccionCliente, fontNormal));
infoCliente.setSpacingAfter(20);
document.add(infoCliente);
// Agregar detalles de la factura
PdfPTable tablaDetalles = new PdfPTable(5);
tablaDetalles.setWidthPercentage(100);
tablaDetalles.setWidths(new float[]{2, 1, 1,1,1});
// Encabezados de la tabla
PdfPCell celdaProducto = new PdfPCell(new Phrase("Producto", fontNormal));
celdaProducto.setHorizontalAlignment(Element.ALIGN_CENTER);
tablaDetalles.addCell(celdaProducto);
PdfPCell celdaCantidad = new PdfPCell(new Phrase("Cantidad", fontNormal));
celdaCantidad.setHorizontalAlignment(Element.ALIGN_CENTER);
tablaDetalles.addCell(celdaCantidad);
PdfPCell celdaPrecio = new PdfPCell(new Phrase("Precio", fontNormal));
celdaPrecio.setHorizontalAlignment(Element.ALIGN_CENTER);
tablaDetalles.addCell(celdaPrecio);
PdfPCell celdaImpuesto = new PdfPCell(new Phrase("Impuesto", fontNormal));
celdaImpuesto.setHorizontalAlignment(Element.ALIGN_CENTER);
tablaDetalles.addCell(celdaImpuesto);
PdfPCell celdaTotal = new PdfPCell(new Phrase("Total", fontNormal));
celdaTotal.setHorizontalAlignment(Element.ALIGN_CENTER);
tablaDetalles.addCell(celdaTotal);
// Filas de la tabla
tablaDetalles.addCell(new Phrase(producto, fontNormal));
tablaDetalles.addCell(String.valueOf(value));
tablaDetalles.addCell(Precio);
tablaDetalles.addCell(String.valueOf(impuesto));
tablaDetalles.addCell(String.valueOf(total));                                                                                                                                                                    
document.add(tablaDetalles);
document.add(imagen);
document.close();

} catch(FileNotFoundException | DocumentException ex){
    Logger.getLogger(Factura.class.getName()).log(Level.SEVERE,null,ex);
}   catch (IOException ex) {
        Logger.getLogger(Factura.class.getName()).log(Level.SEVERE, null, ex);
    }
}
  
}

  


























