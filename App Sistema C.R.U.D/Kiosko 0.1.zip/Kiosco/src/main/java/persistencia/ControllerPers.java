
package persistencia;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import logica.Producto;
import persistencia.exceptions.NonexistentEntityException;

public class ControllerPers {

 
    ProductoJpaController usu = new  ProductoJpaController();

    public void registrar(Producto inve) {
        
        usu.create(inve);
                
 
    }
public  List<Producto> traerProducto() {
  return usu.findProductoEntities();
    }

    public void BorrarProducto(int idPro) {
        try {
            usu.destroy(idPro);
        } catch (NonexistentEntityException ex) {
            Logger.getLogger(ControllerPers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Producto traerProducto(int idPro) {
return usu.findProducto(idPro);
    }

    
 public void modic(Producto inve) {
        try {
            usu.edit(inve);
        } catch (Exception ex) {
            Logger.getLogger(ControllerPers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

    