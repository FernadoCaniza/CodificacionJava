
package persistencia;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import logica.Cliente;
import persistencia.exceptions.NonexistentEntityException;

public class ControllerPers1 {

 
   ClienteJpaController usu1 = new ClienteJpaController();

    public void registrar(Cliente inve1) {
        
        usu1.create(inve1);
                
 
    }
public  List<Cliente> traerCliente() {
  return usu1.findClienteEntities();
    }

    public void BorrarCliente(int idCli) {
        try {
            usu1.destroy(idCli);
        } catch (NonexistentEntityException ex) {
            Logger.getLogger(ControllerPers1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Cliente traerCliente(int idCli) {
return usu1.findCliente(idCli);
    }

    
 public void modic(Cliente inve1) {
        try {
            usu1.edit(inve1);
        } catch (Exception ex) {
            Logger.getLogger(ControllerPers1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

    