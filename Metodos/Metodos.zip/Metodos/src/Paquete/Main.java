package Paquete;

public class Main {
    public static void main(String[] args) {
        int x = entrada();
        System.out.println("El retorno " + x);

        float res2 = Operaciones.multi(10, 10);
        System.out.println("El resultado "+ res2);
    }

    private static int entrada() {
        System.out.println("Hello Word");
        return 123434;
    }

}