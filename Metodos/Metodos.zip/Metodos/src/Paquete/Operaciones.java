package Paquete;

public class Operaciones {
    public static float multi(float x, float y){
        return x * y;

    }
}
