package Paquete;

public class Gelatina{
    //atributo
    String color;
    String sabor;
    // metodos getter
    public String getColor(){
        return this.color;
    }
    public String getSabor(){
        return this.sabor;
    }
    //metodos setter
    public void setColor(String C){
        this.color = C;
    }
    public void setSabor(String S){
        this.sabor = S;
    }
    //Metodo para obtener toda la info de nuestros atributos
    public void mostrarInfo(){
        System.out.println("La informacion de la gelatina es: ");
        System.out.println("Sabor:" + getSabor());
        System.out.println("Color:" + getColor());
    }
}

