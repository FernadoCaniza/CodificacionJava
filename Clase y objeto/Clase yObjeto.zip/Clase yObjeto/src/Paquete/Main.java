package  Paquete;

public class Main {
    public static void main(String[] args) {
        //crear un objeto a partir de una clase - instacia
        Gelatina g1 = new Gelatina();
        g1.setColor("Verde");
        g1.setSabor("Limon");

        g1.mostrarInfo();


        Gelatina g2 = new Gelatina();
        g2.setColor("Amarillo");
        g2.setSabor("Naranja");

        g2.mostrarInfo();

    }

}